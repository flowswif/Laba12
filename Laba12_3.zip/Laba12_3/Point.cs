﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;
using Laba10;

namespace Laba12_3
{
    public class Point<T> where T : IComparable
    {
        public T? Data { get; set; }
        public Point<T>? Left { get; set; }
        public Point<T>? Right { get; set; }
        //public static Point<T> MakeRandomData()
        //{
        //    T data = new T();
        //    if (data is IInit)
        //    {
        //        (data as IInit).IRandomInit();
        //    }
        //    else
        //    {
        //        throw new Exception("Type T does not implement the Ilist interface");
        //    }
        //    return new Point<T>(data);
        //}
        //public static T MakeRandomItem()
        //{
        //    T data = new T();
        //    if (data is IInit)
        //    {
        //        (data as IInit).IRandomInit();
        //    }
        //    else
        //    {
        //        throw new Exception("Type T does not implement the Ilist interface");
        //    }
        //    return data;
        //}

        public Point()
        {
            this.Data = default(T);
            this.Left = null;
            this.Right = null;
        }
        public Point(T data)
        {
            this.Data = data;
            this.Left = null;
            this.Right = null;
        }

        public override string ToString()
        {
            //return Data == null ? "" : Data.ToString();
            if (Data == null)
                return "";
            else
                return Data.ToString();

        }

        public int CompareTo(Point<T> other) { return Data.CompareTo(other.Data); }

        //public override int GetHashCode()
        //{
        //    return Data == null ? 0 : Data.GetHashCode();
        //}
    }
}
