﻿using System;
using ClassLibrary1;
using Laba10;

namespace Laba12_3
{
    class Program
    {
        static void Main(string[] args)
        {
            MyTree<ControlElement> tree = null;
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("1. Создать дерево");
                Console.WriteLine("2. Показать дерево");
                Console.WriteLine("3. Посчитать количество листьев");
                Console.WriteLine("4. Удалить элемент по ключу");
                Console.WriteLine("5. Очистить дерево");
                Console.WriteLine("6. Преобразовать в дерево поиска");
                Console.WriteLine("7. Выйти");

                Console.Write("Выберите действие: ");
                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Ошибка: введите число от 1 до 7.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        Console.Write("Введите количество элементов в дереве: ");
                        int length;
                        if (!int.TryParse(Console.ReadLine(), out length))
                        {
                            Console.WriteLine("Ошибка: введите корректное число.");
                            continue;
                        }
                        tree = new MyTree<ControlElement>(length);
                        
                        Console.WriteLine("Дерево создано.");
                        break;
                    case 2:
                        if (tree == null)
                        {
                            Console.WriteLine("Ошибка: дерево не создано.");
                            continue;
                        }
                        Console.WriteLine("Дерево:");
                        tree.ShowTree();
                        break;
                    case 3:
                        if (tree == null)
                        {
                            Console.WriteLine("Ошибка: дерево не создано.");
                            continue;
                        }
                        Console.WriteLine($"Количество листьев: {tree.CountLeaves()}");
                        break;
                    case 4:
                        if (tree == null)
                        {
                            Console.WriteLine("Ошибка: дерево не создано.");
                            continue;
                        }
                        Console.Write("Введите ключ для удаления: ");
                        ControlElement key = new ControlElement();
                        key.Init();
                        if (tree.Remove(key))
                            Console.WriteLine($"Элемент с ключом {key} успешно удален.");
                        else
                            Console.WriteLine($"Элемент с ключом {key} не найден.");
                        break;
                    case 5:
                        if (tree == null)
                        {
                            Console.WriteLine("Ошибка: дерево не создано.");
                            continue;
                        }
                        tree.ClearTree();
                        Console.WriteLine("Дерево очищено.");
                        break;
                    case 6:
                        if (tree == null)
                        {
                            Console.WriteLine("Ошибка: дерево не создано.");
                            continue;
                        }
                        tree.TransfromToFindTree();
                        Console.WriteLine("Дерево преобразовано в дерево поиска.");
                        break;
                    case 7:
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Ошибка: введите число от 1 до 7.");
                        break;
                }

                Console.WriteLine();
            }
        }
    }
}
